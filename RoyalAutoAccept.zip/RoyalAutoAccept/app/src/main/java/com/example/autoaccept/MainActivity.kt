package com.example.autoaccept

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var pkg: EditText
    private lateinit var kw: EditText
    private lateinit var km: EditText
    private lateinit var sw: Switch

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(s: String) = TextView(this).apply { text = s; setPadding(0, pad / 2, 0, 0) }

        root.addView(label("Driver app package name (e.g. com.royal.driver)"))
        pkg = EditText(this).apply { setText(p.targetPackage); setSingleLine() }
        root.addView(pkg)

        root.addView(label("Accept button words (comma separated)"))
        kw = EditText(this).apply { setText(p.keywords.joinToString(", ")); setSingleLine() }
        root.addView(kw)

        root.addView(label("Max pickup distance in km (0 = any)"))
        km = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(p.maxKm.toString())
        }
        root.addView(km)

        sw = Switch(this).apply { text = "Auto-accept enabled"; isChecked = p.enabled }
        root.addView(sw)

        root.addView(Button(this).apply {
            text = "Save"
            setOnClickListener { save(); Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show() }
        })
        root.addView(Button(this).apply {
            text = "Open Accessibility settings (turn service ON)"
            setOnClickListener { save(); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(label(
            "Steps: 1) enter the driver app package, 2) Save, 3) enable 'Royal Auto Accept' in " +
            "Accessibility, 4) keep the driver app open on screen."
        ))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun save() {
        val p = Prefs(this)
        p.targetPackage = pkg.text.toString()
        p.keywords = kw.text.toString().split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        p.maxKm = km.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
        p.enabled = sw.isChecked
    }

    override fun onPause() { super.onPause(); save() }
}
