package com.example.autoaccept

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    // Package name of the Royal Driver app (see README for how to find it)
    var targetPackage: String
        get() = sp.getString("pkg", "") ?: ""
        set(v) = sp.edit().putString("pkg", v.trim()).apply()

    // Comma-separated words that appear on the Accept button
    var keywords: List<String>
        get() = (sp.getString("kw", "accept,принять,қабылдау,qabul") ?: "")
            .split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("kw", v.joinToString(",")).apply()

    // 0 = accept any distance
    var maxKm: Double
        get() = sp.getFloat("maxKm", 2.0f).toDouble()
        set(v) = sp.edit().putFloat("maxKm", v.toFloat()).apply()

    var cooldownMs: Long
        get() = sp.getLong("cooldown", 1500L)
        set(v) = sp.edit().putLong("cooldown", v).apply()
}
