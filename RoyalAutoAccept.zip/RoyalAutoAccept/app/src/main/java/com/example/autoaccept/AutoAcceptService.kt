package com.example.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AutoAcceptService : AccessibilityService() {

    private var lastClick = 0L
    private val distRegex = Regex("""(\d+(?:[.,]\d+)?)\s*(km|км|m|м)(?![\p{L}\d])""", RegexOption.IGNORE_CASE)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val prefs = Prefs(this)
        if (!prefs.enabled) return
        val target = prefs.targetPackage
        if (target.isEmpty()) return
        if (event?.packageName?.toString() != target) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastClick < prefs.cooldownMs) return

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != target) return

        val keywords = prefs.keywords
        val texts = ArrayList<String>()
        val buttons = ArrayList<AccessibilityNodeInfo>()
        walk(root, keywords, texts, buttons)
        if (buttons.isEmpty()) return

        val km = parseDistanceKm(texts)
        if (prefs.maxKm > 0 && km != null && km > prefs.maxKm) return

        for (b in buttons) {
            if (clickNode(b)) {
                lastClick = now
                return
            }
        }
    }

    private fun walk(
        n: AccessibilityNodeInfo?, kw: List<String>,
        texts: MutableList<String>, buttons: MutableList<AccessibilityNodeInfo>
    ) {
        if (n == null) return
        val t = (n.text ?: n.contentDescription)?.toString()
        if (!t.isNullOrBlank()) {
            texts.add(t)
            val low = t.lowercase()
            if (n.isVisibleToUser && kw.any { low == it || low.contains(it) } && t.length <= 30) {
                buttons.add(n)
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), kw, texts, buttons)
    }

    private fun parseDistanceKm(texts: List<String>): Double? {
        for (t in texts) {
            val m = distRegex.find(t) ?: continue
            val v = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: continue
            val unit = m.groupValues[2].lowercase()
            return if (unit == "km" || unit == "км") v else v / 1000.0
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        // Fallback: tap the centre of the button on screen
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        return dispatchGesture(g, null, null)
    }

    override fun onInterrupt() {}
}
