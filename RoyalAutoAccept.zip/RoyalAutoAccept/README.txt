ROYAL AUTO ACCEPT - Android Studio project

BUILD THE APK
1. Install Android Studio (free) and open this folder.
2. Wait for Gradle sync, then: Build > Build Bundle(s)/APK(s) > Build APK(s).
3. APK is in app/build/outputs/apk/debug/app-debug.apk. Copy to phone and install.

SET UP ON PHONE
1. Find the driver app's package name: Settings > Apps > Royal Driver > App info
   (or install "Package Name Viewer"). Enter it in this app and press Save.
2. Open Accessibility settings from the app, enable "Royal Auto Accept"
   (on Android 13+ you may first need App info > ⋮ > Allow restricted settings).
3. Turn off battery optimization for both apps. Keep the driver app on screen.

TUNING
- If it does not tap, the Accept button text differs: add its exact text to the words list.
- Distance is read from any text like "1.2 km" or "800 m" on the order popup.
- Cooldown between taps: 1.5 s (Prefs.kt).
NOTE: automation may violate the driver app's terms; use at your own risk.

NO ANDROID STUDIO? BUILD ONLINE FREE
1. Make a free account at github.com, create a new repository.
2. Upload ALL files from this folder (including the hidden .github folder) to it.
3. Open the Actions tab > "Build APK" > wait ~3-5 min until green.
4. Open the finished run, download "RoyalAutoAccept-apk" (a zip containing app-debug.apk).
5. Copy app-debug.apk to your ANDROID phone and install it.
